let in1 = document.querySelector('.input1');
let in2 = document.querySelector('.input2');
let bt1 = document.querySelector('#bt1');
let bt2 = document.querySelector('#bt2');
let bt3 = document.querySelector('#bt3');
let bt4 = document.querySelector('#bt4');
let bt5 = document.querySelector('#bt5');
let bt6 = document.querySelector('#bt6');
let bt7 = document.querySelector('#bt7');
let bt8 = document.querySelector('#bt8');
let bt9 = document.querySelector('#bt9');
let bt0 = document.querySelector('#bt0');
let btplus = document.querySelector('#btplus');
let btminus = document.querySelector('#btminus');
let btdiv = document.querySelector('#btdiv');
let btmulti = document.querySelector('#btmulti');
let bteq = document.querySelector('#bteq');
let btdot = document.querySelector('#btdot');
let btc1 = document.querySelector('#c1');
let btc2 = document.querySelector('#c2');

let buttonList = document.getElementsByClassName('button');

for(let i of buttonList ){
	i.addEventListener('mousedown', btMouseDownColorChange);
	i.addEventListener('mouseup', btMouseUpColorChange);
}

 btc1.addEventListener('mousedown', clMouseDownColorChange);
 btc1.addEventListener('mouseup', clMouseUpColorChange);

 btc2.addEventListener('mousedown', clMouseDownColorChange);
 btc2.addEventListener('mouseup', clMouseUpColorChange);


let input2Value='';
let valueCompute1='';
let valueCompute2='';
let activeOperator='';
let operatorForEqu='';
let equClick=false;
let divBZE=false;


function btMouseDownColorChange(){
	this.style.background='skyblue';
}

function btMouseUpColorChange(){
	this.style.background='rgb(230,230,230)';
}

function clMouseDownColorChange(){
	if(this==btc1){
		this.style.background='skyblue';
	}
	if(this==btc2){
		this.style.background='skyblue';
	}

}

function clMouseUpColorChange(){
	if(this==btc1){
		this.style.background='rgb(164, 209, 237)';
	}
	if(this==btc2){
		this.style.background='rgb(238, 164, 134)';
	};
}


/*  ..................... bt1 EVENT & FUNCTION ............................*/
bt1.addEventListener('click', bt1f);


function bt1f(){
	let confirm;
	confirm = canWrite(input2Value);

	if(divBZE){
		in1.textContent='';
		divBZE=false
	}
	
	if (confirm){
	  if(equClick){
	      input2Value = bt1.textContent;
		in2.textContent = input2Value;
		valueCompute1='';
		equClick=false;
		return;
	  }
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt1.textContent;
	in2.textContent = input2Value;
	}else{
		input2Value += bt1.textContent;
		in2.textContent = input2Value;
		}	

	}else{
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt1.textContent;
	in2.textContent = input2Value;
	}
		}	

}

/*  .......................................................................*/


/*  ..................... bt2 EVENT & FUNCTION ............................*/
bt2.addEventListener('click', bt2f);

function bt2f(){
let confirm;
	confirm = canWrite(input2Value);
	if(divBZE){
		in1.textContent='';
		divBZE=false
	}
	
	if (confirm){
	if(equClick){
	      input2Value = this.textContent;
		in2.textContent = input2Value;
		valueCompute1='';
		equClick=false;
		return;
	  }
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt2.textContent;
	in2.textContent = input2Value;
	}else{
		input2Value += bt2.textContent;
		in2.textContent = input2Value;
		}	
	}else{
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt2.textContent;
	in2.textContent = input2Value;
	}
		}		
}

/*  .......................................................................*/


/*  ..................... bt3 EVENT & FUNCTION ............................*/
bt3.addEventListener('click', bt3f);

function bt3f(){
let confirm;
	confirm = canWrite(input2Value);

	if(divBZE){
		in1.textContent='';
		divBZE=false
	}
	
	if (confirm){
	if(equClick){
	      input2Value = this.textContent;
		in2.textContent = input2Value;
		valueCompute1='';
		equClick=false;
		return;
	  }
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt3.textContent;
	in2.textContent = input2Value;
	}else{
		input2Value += bt3.textContent;
		in2.textContent = input2Value;
		}	
	}else{
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt3.textContent;
	in2.textContent = input2Value;
	}
		}		
}

/*  .......................................................................*/


/*  ..................... bt4 EVENT & FUNCTION ............................*/
bt4.addEventListener('click', bt4f);

function bt4f(){
let confirm;
	confirm = canWrite(input2Value);

	if(divBZE){
		in1.textContent='';
		divBZE=false
	}
	
	if (confirm){
	if(equClick){
	      input2Value = this.textContent;
		in2.textContent = input2Value;
		valueCompute1='';
		equClick=false;
		return;
	  }
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt4.textContent;
	in2.textContent = input2Value;
	}else{
		input2Value += bt4.textContent;
		in2.textContent = input2Value;
		}	
	}else{
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt4.textContent;
	in2.textContent = input2Value;
	}
		}		
}

/*  .......................................................................*/


/*  ..................... bt5 EVENT & FUNCTION ............................*/
bt5.addEventListener('click', bt5f);

function bt5f(){
let confirm;
	confirm = canWrite(input2Value);

	if(divBZE){
		in1.textContent='';
		divBZE=false
	}
	
	if (confirm){
	if(equClick){
	      input2Value = this.textContent;
		in2.textContent = input2Value;
		valueCompute1='';
		equClick=false;
		return;
	  }
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt5.textContent;
	in2.textContent = input2Value;
	}else{
		input2Value += bt5.textContent;
		in2.textContent = input2Value;
		}	
	}else{
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt5.textContent;
	in2.textContent = input2Value;
	}
		}		
}

/*  .......................................................................*/


/*  ..................... bt6 EVENT & FUNCTION ............................*/
bt6.addEventListener('click', bt6f);

function bt6f(){
let confirm;
	confirm = canWrite(input2Value);

	if(divBZE){
		in1.textContent='';
		divBZE=false
	}
	
	if (confirm){
	if(equClick){
	      input2Value = this.textContent;
		in2.textContent = input2Value;
		valueCompute1='';
		equClick=false;
		return;
	  }
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt6.textContent;
	in2.textContent = input2Value;
	}else{
		input2Value += bt6.textContent;
		in2.textContent = input2Value;
		}	
	}else{
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt6.textContent;
	in2.textContent = input2Value;
	}
		}		
}

/*  .......................................................................*/


/*  ..................... bt7 EVENT & FUNCTION ............................*/
bt7.addEventListener('click', bt7f);

function bt7f(){
let confirm;
	confirm = canWrite(input2Value);

	if(divBZE){
		in1.textContent='';
		divBZE=false
	}
	
	if (confirm){
	if(equClick){
	      input2Value = this.textContent;
		in2.textContent = input2Value;
		valueCompute1='';
		equClick=false;
		return;
	  }
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt7.textContent;
	in2.textContent = input2Value;
	}else{
		input2Value += bt7.textContent;
		in2.textContent = input2Value;
		}	
	}else{
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt7.textContent;
	in2.textContent = input2Value;
	}
		}		
}

/*  .......................................................................*/


/*  ..................... bt8 EVENT & FUNCTION ............................*/
bt8.addEventListener('click', bt8f);

function bt8f(){
let confirm;
	confirm = canWrite(input2Value);

	if(divBZE){
		in1.textContent='';
		divBZE=false
	}
	
	if (confirm){
	if(equClick){
	      input2Value = this.textContent;
		in2.textContent = input2Value;
		valueCompute1='';
		equClick=false;
		return;
	  }
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt8.textContent;
	in2.textContent = input2Value;
	}else{
		input2Value += bt8.textContent;
		in2.textContent = input2Value;
		}	
	}else{
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt8.textContent;
	in2.textContent = input2Value;
	}
		}		
}

/*  .......................................................................*/


/*  ..................... bt9 EVENT & FUNCTION ............................*/
bt9.addEventListener('click', bt9f);

function bt9f(){
let confirm;
	confirm = canWrite(input2Value);

	if(divBZE){
		in1.textContent='';
		divBZE=false
	}
	
	if (confirm){
	if(equClick){
	      input2Value = this.textContent;
		in2.textContent = input2Value;
		valueCompute1='';
		equClick=false;
		return;
	  }
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt9.textContent;
	in2.textContent = input2Value;
	}else{
		input2Value += bt9.textContent;
		in2.textContent = input2Value;
		}	
	}else{
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt9.textContent;
	in2.textContent = input2Value;
	}
		}		
}

/*  .......................................................................*/


/*  ..................... bt0 EVENT & FUNCTION ............................*/
bt0.addEventListener('click', bt0f);

function bt0f(){
let confirm;
	confirm = canWrite(input2Value);

	if(divBZE){
		in1.textContent='';
		divBZE=false
	}
	
	if (confirm){
	if(equClick){
	      input2Value = this.textContent;
		in2.textContent = input2Value;
		valueCompute1='';
		equClick=false;
		return;
	  }
		if(in2.textContent===0 || in2.textContent==='0'){
			in2.textContent = '0';
			return;
		}
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt0.textContent;
	in2.textContent = input2Value;
	}else{
		input2Value += bt0.textContent;
		in2.textContent = input2Value;
		}	
	}else{
		if(activeOperator =='+'|| activeOperator =='-'|| activeOperator =='x'|| activeOperator =='/' ){
	input2Value='';
	operatorForEqu = activeOperator;
	activeOperator='';
	input2Value += bt0.textContent;
	in2.textContent = input2Value;
	}
		}		
}

/*  .......................................................................*/


/*  ..................... btdot EVENT & FUNCTION ............................*/
btdot.addEventListener('click', btdotf);

function btdotf(){
	if (canDot(input2Value)){
		if(input2Value ==''){
			input2Value='0';
			input2Value += btdot.textContent;
			in2.textContent = input2Value;
		}
		else{
			input2Value += btdot.textContent;
			in2.textContent = input2Value;
		}
	}
}

/*  .......................................................................*/


/*  ..................... CLEAR INPUT 2 EVENT & FUNCTION ............................*/
btc2.addEventListener('click', btc2f);

function btc2f(){
	if(divBZE){
		in1.textContent='';
		divBZE=false
	}
	
	input2Value = '';
	valueCompute1='';
	in2.textContent = '0';
	equClick=false;
}

/*  .......................................................................*/


/*  ..................... CLEAR by BACKWARDS ONE INPUT ............................*/
btc1.addEventListener('click', btc1f);

function btc1f(){
	let arrayedInput;
	let popedArrayedInput;
	let toDisplay;
	
	arrayedInput = input2Value.split('');
	arrayedInput.pop();
	toDisplay = arrayedInput.join('');

	if(equClick){return;}

	if(toDisplay =='' || toDisplay == '0'){
	in2.textContent = '0';
	input2Value = '';
	} 
		else{
			in2.textContent = toDisplay;
			input2Value = toDisplay;
		}

}

/*  .......................................................................*/


/*  .................FUNCTION to CHECK FOR DISPLAY RANGE............................*/

function canWrite(input2Value){
let value = input2Value.length;
if(value < 12){ return true}
	else{return false}
}

/*  .......................................................................*/


/*  .................FUNCTION FOR DECIMAL POINT INCLUSION............................*/

function canDot(input2Value){
for (let i in input2Value){
	if ('.' == input2Value[i]){return false;}
	}
return true;
}

/*  .......................................................................*/



/*  ..................... btplus EVENT & FUNCTION ............................*/
btplus.addEventListener('click', btplusf);

function btplusf(){
   activeOperator = btplus.textContent;

   if(!(Boolean(valueCompute1))){
   		if(valueCompute1===0){
   		operatorFunction();
   		 }
   		else{valueCompute1 = Number(input2Value);}
    }
    	else{
    		operatorFunction();
    	}
	
}

/*  .......................................................................*/


/*  ..................... btminus EVENT & FUNCTION ............................*/
btminus.addEventListener('click', btminusf);

function btminusf(){
   activeOperator = btminus.textContent;

   if(!(Boolean(valueCompute1))){
   		if(valueCompute1===0){
   		operatorFunction();
   		 }
   		else{valueCompute1 = Number(input2Value);}
    }
    	else{
    		operatorFunction();
    	}
	
}

/*  .......................................................................*/



/*  ..................... btdiv EVENT & FUNCTION ............................*/
btdiv.addEventListener('click', btdivf);

function btdivf(){
   activeOperator = btdiv.textContent;

   if(!(Boolean(valueCompute1))){
   		if(valueCompute1===0){
   		operatorFunction();
   		 }
   		else{valueCompute1 = Number(input2Value);}
    }
    	else{
    		operatorFunction();
    	}
	
}

/*  .......................................................................*/


/*  ..................... btmulti EVENT & FUNCTION ............................*/
btmulti.addEventListener('click', btmultif);

function btmultif(){
   activeOperator = btmulti.textContent;

   if(!(Boolean(valueCompute1))){
   		if(valueCompute1===0){
   		operatorFunction();
   		 }
   		else{valueCompute1 = Number(input2Value);}
    }
    	else{
    		operatorFunction();
    	}
	
}

/*  .......................................................................*/



/*  ..................... bteq EVENT & FUNCTION ............................*/
bteq.addEventListener('click', bteqf);

function bteqf(){

	equClick=true;
	
switch(operatorForEqu){
   				case '+' : valueCompute1 += Number(input2Value); 
   				in2.textContent= String(valueCompute1);
   				break;

   				case '-' : valueCompute1 -= Number(input2Value); 
   				in2.textContent= String(valueCompute1);
   				break;

   				case '/' : if(Number(input2Value)===0){
   					in2.textContent= ''; 
   					in1.textContent= 'Cannot Divide by Zero';
   					divBZE=true;  
   				}else{valueCompute1 /= Number(input2Value); 
   				let value = String(valueCompute1);
   				if (value.length >= 12){
   				    in2.textContent= (valueCompute1.toFixed(12));
   				}else{
   				in2.textContent= String(valueCompute1);}}
   				break;

   				case 'x' : valueCompute1 *= Number(input2Value); 
   				let value1 = String(valueCompute1);
   				if (value1.length >12){
   				    in2.textContent= (valueCompute1.toExponential(10));
   				    }else{
   				in2.textContent= String(valueCompute1);
   				}
   				break;

   			}
   		
}

/*  .......................................................................*/


function operatorFunction(){

	if (equClick){
		/*input2Value = valueCompute1;*/
		equClick=false;
	}
	else{
	console.log ('just left equ check');
switch(operatorForEqu){
   				case '+' : valueCompute1 += Number(input2Value); 
   				in2.textContent= String(valueCompute1);
   				input2Value='';
   				break;

   				case '-' : valueCompute1 -= Number(input2Value); 
   				in2.textContent= String(valueCompute1);
   				input2Value='';
   				break;

   				case '/' : if(Number(input2Value)===0){
   					in2.textContent= ''; 
   					in1.textContent= 'Cannot Divide by Zero'; 
   					divBZE=true;  					
   				}else{valueCompute1 /= Number(input2Value); 
   				let value = String(valueCompute1);
   				if (value.length >= 10){
   				    in2.textContent= (valueCompute1.toFixed(12));
   				    input2Value='';
   				}else{
   				in2.textContent= String(valueCompute1);
   				input2Value='';}}
   				break;

   				case 'x' : valueCompute1 *= Number(input2Value); 
   				let value1 = String(valueCompute1);
   				if (value1.length >12){
   				    in2.textContent= (valueCompute1.toExponential(10));
   				    input2Value='';
   				}else{
   				in2.textContent= String(valueCompute1);
   				input2Value='';}
   				break;


   			}
   }

}
